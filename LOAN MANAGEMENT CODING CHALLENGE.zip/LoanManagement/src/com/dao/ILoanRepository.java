package com.dao;


import com.hexaware.entity.Loan;
import com.hexaware.exception.InvalidLoanException;

import java.util.List;

public interface ILoanRepository {
    void applyLoan(Loan loan) throws InvalidLoanException;
    double calculateInterest(int loanID) throws InvalidLoanException;
    void loanStatus(int loanID) throws InvalidLoanException;
    double calculateEMI(int loanID) throws InvalidLoanException;
    int loanRepayment(int loanID, double amount) throws InvalidLoanException;
    List<Loan> getAllLoan() throws InvalidLoanException;
    Loan getLoanById(int loanID) throws InvalidLoanException;
	double calculateEMI(double principalAmount, double interestRate, int loanTerm) throws InvalidLoanException;
	Loan getLoanById(Loan loanId) throws InvalidLoanException;
	short getLoanById(short loanId) throws InvalidLoanException;
}
package com.hexaware.entity;

public enum LoanType {
    CarLoan,
    HomeLoan
}

/**
 * 
 */
/**
 * 
 */
module J224_Laxmi_Lohith_Vallampati_LoanManagement {
	requires java.sql;
}
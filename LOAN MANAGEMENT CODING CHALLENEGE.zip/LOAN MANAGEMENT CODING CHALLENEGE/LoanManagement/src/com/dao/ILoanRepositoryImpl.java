package com.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.hexaware.entity.Loan;
import com.hexaware.exception.InvalidLoanException;
import com.hexaware.util.DBUtil;

public abstract class ILoanRepositoryImpl implements ILoanRepository {
	    private Connection connection;

	    public ILoanRepositoryImpl() {
	        this.connection = DBUtil.getDBConn();
	    }

	    @Override
	    public void applyLoan(Loan loan) throws InvalidLoanException {
	    	try {
	            System.out.println("Confirm Loan Details:");
	            System.out.println("Loan ID: " + loan.getLoanID());

	            try (Scanner scanner = new Scanner(System.in)) {
					System.out.print("Confirm loan application? (Yes/No): ");
					String ack = scanner.nextLine();

					if (ack.equalsIgnoreCase("Yes")) {
					    String query = "INSERT INTO loans (loan_id, customer_id, principal_amount, interest_rate, loan_term, loan_type, loan_status) VALUES (?, ?, ?, ?, ?, ?, ?)";
					    PreparedStatement preparedStatement = connection.prepareStatement(query);
					    preparedStatement.setInt(1, loan.getLoanID());
					    preparedStatement.setInt(2, loan.getCustomer().getCustomerID());
					    preparedStatement.setDouble(3, loan.getPrincipalAmount());
					    preparedStatement.setDouble(4, loan.getInterestRate());
					    preparedStatement.setInt(5, loan.getLoanTerm());
					    preparedStatement.setString(6, loan.getLoanType());
					    preparedStatement.setString(7, "Pending"); 
					    preparedStatement.executeUpdate();
					    System.out.println("Loan application submitted successfully.");
					} else {
					    System.out.println("Loan application canceled.");
					}
				}
	        } catch (SQLException e) {
	            throw new InvalidLoanException(null);
	        }
	    }

	    @Override
	    public double calculateInterest(int loanId) throws InvalidLoanException {
	    	 double principalAmount;
	         double interestRate;
	         int loanTerm;

	         try {
	             String query = "SELECT principal_amount, interest_rate, loan_term FROM loans WHERE loan_id = ?";
	             PreparedStatement preparedStatement = connection.prepareStatement(query);
	             preparedStatement.setInt(1, loanId);
	             ResultSet resultSet = preparedStatement.executeQuery();

	             if (resultSet.next()) {
	                 principalAmount = resultSet.getDouble("principal_amount");
	                 interestRate = resultSet.getDouble("interest_rate");
	                 loanTerm = resultSet.getInt("loan_term");

	                 return (principalAmount * interestRate * loanTerm) / 12;
	             } else {
	                 throw new InvalidLoanException(query);
	             }
	         } catch (SQLException e) {
	             throw new InvalidLoanException(null);
	         }
	     }
	    

	    @Override
	    public void loanStatus(int loanId) throws InvalidLoanException {
	    	   try {
	               String query = "SELECT l.loan_id, l.customer_id, c.credit_score FROM loans l INNER JOIN customers c ON l.customer_id = c.customer_id WHERE l.loan_id = ?";
	               PreparedStatement preparedStatement = connection.prepareStatement(query);
	               preparedStatement.setInt(1, loanId);
	               ResultSet resultSet = preparedStatement.executeQuery();

	               if (resultSet.next()) {
	                   int customerId = resultSet.getInt("customer_id");
	                   int creditScore = resultSet.getInt("credit_score");

	                   String loanStatus = (creditScore > 650) ? "Approved" : "Rejected";

	                   String updateQuery = "UPDATE loans SET loan_status = ? WHERE loan_id = ?";
	                   PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
	                   updateStatement.setString(1, loanStatus);
	                   updateStatement.setInt(2, loanId);
	                   updateStatement.executeUpdate();

	                   System.out.println("Loan status updated: " + loanStatus);
	               } else {
	                   throw new InvalidLoanException(query);
	               }
	           } catch (SQLException e) {
	               throw new InvalidLoanException(null);
	           }
	    }

	    @Override
	    public double calculateEMI(int loanId) throws InvalidLoanException {
	    	 double principalAmount;
	         double interestRate;
	         int loanTerm;

	         try {
	             String query = "SELECT principal_amount, interest_rate, loan_term FROM loans WHERE loan_id = ?";
	             PreparedStatement preparedStatement = connection.prepareStatement(query);
	             preparedStatement.setInt(1, loanId);
	             ResultSet resultSet = preparedStatement.executeQuery();

	             if (resultSet.next()) {
	                 principalAmount = resultSet.getDouble("principal_amount");
	                 interestRate = resultSet.getDouble("interest_rate");
	                 loanTerm = resultSet.getInt("loan_term");

	                 return calculateEMI(principalAmount, interestRate, loanTerm);
	             } else {
	                 throw new InvalidLoanException("Loan not found with ID: " + loanId);
	             }
	         } catch (SQLException e) {
	             throw new InvalidLoanException("Error calculating EMI: " + e.getMessage());
	         }
	     }

	     

	    @Override
	    public int loanRepayment(int loanId, double amount) throws InvalidLoanException {
	        try {
	            // Retrieve loan details from the database
	            String query = "SELECT principal_amount, interest_rate, loan_term FROM loans WHERE loan_id = ?";
	            PreparedStatement preparedStatement = connection.prepareStatement(query);
	            preparedStatement.setInt(1, loanId);
	            ResultSet resultSet = preparedStatement.executeQuery();

	            if (resultSet.next()) {
	                double principalAmount = resultSet.getDouble("principal_amount");
	                double interestRate = resultSet.getDouble("interest_rate");
	                int loanTerm = resultSet.getInt("loan_term");

	                // Calculate EMI
	                double emi = calculateEMI(principalAmount, interestRate, loanTerm);

	                // Calculate number of EMIs that can be paid
	                int noOfEmiPaid = (int) (amount / emi);
	                
	                // If amount is less than EMI, reject payment
	                if (amount < emi) {
	                    System.out.println("Payment rejected. Amount is less than the EMI.");
	                    return 0; // No EMIs paid
	                }

	                // Update loan repayment variable
	                String updateQuery = "UPDATE loans SET no_of_emi_paid = ? WHERE loan_id = ?";
	                PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
	                updateStatement.setInt(1, noOfEmiPaid);
	                updateStatement.setInt(2, loanId);
	                updateStatement.executeUpdate();

	                System.out.println("Payment processed successfully. Number of EMIs paid: " + noOfEmiPaid);
	                return noOfEmiPaid;
	            } else {
	                throw new InvalidLoanException("Loan not found with ID: " + loanId);
	            }
	        } catch (SQLException e) {
	            throw new InvalidLoanException("Error processing loan repayment: " + e.getMessage());
	        }
	    }

	    // Method to calculate EMI
	    public double calculateEMI(double principalAmount, double interestRate, int loanTerm) {
	        double monthlyInterestRate = interestRate / 12 / 100;
	        double emi = (principalAmount * monthlyInterestRate * Math.pow(1 + monthlyInterestRate, loanTerm)) / (Math.pow(1 + monthlyInterestRate, loanTerm) - 1);
	        return emi;
	    
	    }

	    @Override
	    public List<Loan> getAllLoan() throws InvalidLoanException {
	    	 List<Loan> loanList = new ArrayList<>();

	         try {
	             String query = "SELECT * FROM loans";
	             PreparedStatement preparedStatement = connection.prepareStatement(query);
	             ResultSet resultSet = preparedStatement.executeQuery();

	             while (resultSet.next()) {
	                 int loanId = resultSet.getInt("loan_id");
	                 }
	         } catch (SQLException e) {
	             throw new InvalidLoanException("Error retrieving all loans: " + e.getMessage());
	         }

	         return loanList;
	     }
	    
	    @Override
	    public short getLoanById(short loanId) throws InvalidLoanException {
	    	 try {
	             String query = "SELECT * FROM loans WHERE loan_id = ?";
	             PreparedStatement preparedStatement = connection.prepareStatement(query);
	             preparedStatement.setShort(1, loanId);
	             ResultSet resultSet = preparedStatement.executeQuery();

	             if (resultSet.next()) {
	                 return loanId;
	             } else {
	                 throw new InvalidLoanException("Loan not found with ID: " + loanId);
	             }
	         } catch (SQLException e) {
	             throw new InvalidLoanException("Error retrieving loan: " + e.getMessage());
	         }
	    }


		
		

}
